﻿------English------
QEI - Hap example data

Files used for this analysis:
Fast3VmrMLM\inst\extdata\QTN\SNP\genotype.bed
Fast3VmrMLM\inst\extdata\QTN\SNP\genotype.bim
Fast3VmrMLM\inst\extdata\QTN\SNP\genotype.fam
Fast3VmrMLM\inst\extdata\QEI\SNP\phenotype.csv
Fast3VmrMLM\inst\extdata\QTN\SNP\PCA.csv

Genotypes and PCA are shared with QTN/SNP, and phenotypes are shared with QEI/SNP. The Hap example uses c_threshold=0.7.

------Chinese------
QEI - Hap 示例数据

运行所用文件：
Fast3VmrMLM\inst\extdata\QTN\SNP\genotype.bed
Fast3VmrMLM\inst\extdata\QTN\SNP\genotype.bim
Fast3VmrMLM\inst\extdata\QTN\SNP\genotype.fam
Fast3VmrMLM\inst\extdata\QEI\SNP\phenotype.csv
Fast3VmrMLM\inst\extdata\QTN\SNP\PCA.csv

基因型和 PCA 与 QTN/SNP 共用，表型与 QEI/SNP 共用。Hap 示例 c_threshold=0.7。
