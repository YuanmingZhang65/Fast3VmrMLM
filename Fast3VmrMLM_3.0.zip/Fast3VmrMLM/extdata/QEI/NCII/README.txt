﻿------English------
QEI - NCII example data

Files used for this analysis:
Fast3VmrMLM\inst\extdata\QTN\NCII\genotype.bed
Fast3VmrMLM\inst\extdata\QTN\NCII\genotype.bim
Fast3VmrMLM\inst\extdata\QTN\NCII\genotype.fam
Fast3VmrMLM\inst\extdata\QEI\NCII\phenotype.csv
Fast3VmrMLM\inst\extdata\QTN\NCII\PCA.csv
Fast3VmrMLM\inst\extdata\QTN\NCII\pedigree.csv

Parental genotypes, pedigree, and PCA are shared with QTN/NCII. This folder contains phenotypes for two traits, each measured in three environments.

------Chinese------
QEI - NCII 示例数据

运行所用文件：
Fast3VmrMLM\inst\extdata\QTN\NCII\genotype.bed
Fast3VmrMLM\inst\extdata\QTN\NCII\genotype.bim
Fast3VmrMLM\inst\extdata\QTN\NCII\genotype.fam
Fast3VmrMLM\inst\extdata\QEI\NCII\phenotype.csv
Fast3VmrMLM\inst\extdata\QTN\NCII\PCA.csv
Fast3VmrMLM\inst\extdata\QTN\NCII\pedigree.csv

亲本基因型、系谱和 PCA 与 QTN/NCII 共用；本目录保存两个性状、每性状三个环境的表型。
