﻿------English------
QEI - SNP example data

Files used for this analysis:
Fast3VmrMLM\inst\extdata\QTN\SNP\genotype.bed
Fast3VmrMLM\inst\extdata\QTN\SNP\genotype.bim
Fast3VmrMLM\inst\extdata\QTN\SNP\genotype.fam
Fast3VmrMLM\inst\extdata\QEI\SNP\phenotype.csv
Fast3VmrMLM\inst\extdata\QTN\SNP\PCA.csv

Genotypes and PCA are shared with QTN/SNP. This folder contains phenotypes for three traits, each measured in two environments.

------Chinese------
QEI - SNP 示例数据

运行所用文件：
Fast3VmrMLM\inst\extdata\QTN\SNP\genotype.bed
Fast3VmrMLM\inst\extdata\QTN\SNP\genotype.bim
Fast3VmrMLM\inst\extdata\QTN\SNP\genotype.fam
Fast3VmrMLM\inst\extdata\QEI\SNP\phenotype.csv
Fast3VmrMLM\inst\extdata\QTN\SNP\PCA.csv

基因型和 PCA 与 QTN/SNP 共用；本目录保存三个性状、每性状两个环境的表型。
