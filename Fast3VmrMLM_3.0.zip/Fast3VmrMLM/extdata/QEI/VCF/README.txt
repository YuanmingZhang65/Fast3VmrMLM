﻿------English------
QEI - VCF example data

Files used for this analysis:
Fast3VmrMLM\inst\extdata\QEI\VCF\genotype.vcf
Fast3VmrMLM\inst\extdata\QEI\VCF\phenotype.csv
Fast3VmrMLM\inst\extdata\QTN\SNP\PCA.csv

This folder contains the VCF and phenotype files. PCA is shared with QTN/SNP. The phenotypes cover two traits, each measured in two environments.

------Chinese------
QEI - VCF 示例数据

运行所用文件：
Fast3VmrMLM\inst\extdata\QEI\VCF\genotype.vcf
Fast3VmrMLM\inst\extdata\QEI\VCF\phenotype.csv
Fast3VmrMLM\inst\extdata\QTN\SNP\PCA.csv

本目录保存 VCF 和表型；PCA 与 QTN/SNP 共用。表型为两个性状、每性状两个环境。
