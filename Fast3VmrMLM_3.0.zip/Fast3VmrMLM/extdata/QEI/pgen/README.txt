﻿------English------
QEI - pgen example data

Files used for this analysis:
Fast3VmrMLM\inst\extdata\QEI\pgen\genotype.pgen
Fast3VmrMLM\inst\extdata\QEI\pgen\genotype.pvar
Fast3VmrMLM\inst\extdata\QEI\pgen\genotype.psam
Fast3VmrMLM\inst\extdata\QEI\VCF\phenotype.csv
Fast3VmrMLM\inst\extdata\QTN\SNP\PCA.csv

Phenotypes are shared with QEI/VCF, and PCA is shared with QTN/SNP. The phenotypes cover two traits, each measured in two environments.

------Chinese------
QEI - pgen 示例数据

运行所用文件：
Fast3VmrMLM\inst\extdata\QEI\pgen\genotype.pgen
Fast3VmrMLM\inst\extdata\QEI\pgen\genotype.pvar
Fast3VmrMLM\inst\extdata\QEI\pgen\genotype.psam
Fast3VmrMLM\inst\extdata\QEI\VCF\phenotype.csv
Fast3VmrMLM\inst\extdata\QTN\SNP\PCA.csv

表型与 QEI/VCF 共用，PCA 与 QTN/SNP 共用。表型为两个性状、每性状两个环境。
