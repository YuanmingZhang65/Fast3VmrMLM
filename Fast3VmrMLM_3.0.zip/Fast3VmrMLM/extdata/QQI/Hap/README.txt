﻿------English------
QQI - Hap example data

Files used for this analysis:
Fast3VmrMLM\inst\extdata\QQI\SNP\genotype.bed
Fast3VmrMLM\inst\extdata\QQI\SNP\genotype.bim
Fast3VmrMLM\inst\extdata\QQI\SNP\genotype.fam
Fast3VmrMLM\inst\extdata\QQI\SNP\phenotype.csv
Fast3VmrMLM\inst\extdata\QQI\SNP\PCA.csv

Genotypes, phenotypes, and PCA are shared with QQI/SNP; no duplicate data copies are stored.

------Chinese------
QQI - Hap 示例数据

运行所用文件：
Fast3VmrMLM\inst\extdata\QQI\SNP\genotype.bed
Fast3VmrMLM\inst\extdata\QQI\SNP\genotype.bim
Fast3VmrMLM\inst\extdata\QQI\SNP\genotype.fam
Fast3VmrMLM\inst\extdata\QQI\SNP\phenotype.csv
Fast3VmrMLM\inst\extdata\QQI\SNP\PCA.csv

与 QQI/SNP 共用基因型、表型和 PCA，不重复存放数据。
