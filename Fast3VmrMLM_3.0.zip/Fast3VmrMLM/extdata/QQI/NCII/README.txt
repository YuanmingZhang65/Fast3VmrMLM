﻿------English------
QQI - NCII example data

Files used for this analysis:
Fast3VmrMLM\inst\extdata\QQI\NCII\genotype.bed
Fast3VmrMLM\inst\extdata\QQI\NCII\genotype.bim
Fast3VmrMLM\inst\extdata\QQI\NCII\genotype.fam
Fast3VmrMLM\inst\extdata\QQI\NCII\phenotype.csv
Fast3VmrMLM\inst\extdata\QQI\NCII\PCA.csv
Fast3VmrMLM\inst\extdata\QQI\NCII\pedigree.csv

PCA.csv is supplementary data: expected offspring dosages were inferred from the existing parental genotypes and pedigree. Missing values were imputed using marker means, dosages were standardized, and the first two principal components were extracted without using phenotype values. This file is identical to the supplementary PCA file used in the previous successful retest. Reproduction code: Fast3VmrMLM_3.0_check\extdata_test\supplement_QQI_NCII_PCA.py.

------Chinese------
QQI - NCII 示例数据

运行所用文件：
Fast3VmrMLM\inst\extdata\QQI\NCII\genotype.bed
Fast3VmrMLM\inst\extdata\QQI\NCII\genotype.bim
Fast3VmrMLM\inst\extdata\QQI\NCII\genotype.fam
Fast3VmrMLM\inst\extdata\QQI\NCII\phenotype.csv
Fast3VmrMLM\inst\extdata\QQI\NCII\PCA.csv
Fast3VmrMLM\inst\extdata\QQI\NCII\pedigree.csv

PCA.csv 为补充数据：由原有亲本基因型和系谱推导子代期望剂量，缺失值按标记均值填补并标准化，提取两个主成分，不使用表型值。与此前通过复测的补充 PCA 文件完全一致。复现代码为 Fast3VmrMLM_3.0_check\extdata_test\supplement_QQI_NCII_PCA.py。
