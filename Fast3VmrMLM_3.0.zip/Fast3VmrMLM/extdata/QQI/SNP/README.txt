﻿------English------
QQI - SNP example data

Files used for this analysis:
Fast3VmrMLM\inst\extdata\QQI\SNP\genotype.bed
Fast3VmrMLM\inst\extdata\QQI\SNP\genotype.bim
Fast3VmrMLM\inst\extdata\QQI\SNP\genotype.fam
Fast3VmrMLM\inst\extdata\QQI\SNP\phenotype.csv
Fast3VmrMLM\inst\extdata\QQI\SNP\PCA.csv

------Chinese------
QQI - SNP 示例数据

运行所用文件：
Fast3VmrMLM\inst\extdata\QQI\SNP\genotype.bed
Fast3VmrMLM\inst\extdata\QQI\SNP\genotype.bim
Fast3VmrMLM\inst\extdata\QQI\SNP\genotype.fam
Fast3VmrMLM\inst\extdata\QQI\SNP\phenotype.csv
Fast3VmrMLM\inst\extdata\QQI\SNP\PCA.csv
