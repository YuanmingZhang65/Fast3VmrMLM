﻿------English------
QQI - VCF example data

Files used for this analysis:
Fast3VmrMLM\inst\extdata\QQI\VCF\genotype.vcf
Fast3VmrMLM\inst\extdata\QQI\VCF\phenotype.csv

------Chinese------
QQI - VCF 示例数据

运行所用文件：
Fast3VmrMLM\inst\extdata\QQI\VCF\genotype.vcf
Fast3VmrMLM\inst\extdata\QQI\VCF\phenotype.csv
