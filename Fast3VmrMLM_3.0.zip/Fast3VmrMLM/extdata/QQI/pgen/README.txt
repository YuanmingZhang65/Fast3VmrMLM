﻿------English------
QQI - pgen example data

Files used for this analysis:
Fast3VmrMLM\inst\extdata\QQI\pgen\genotype.pgen
Fast3VmrMLM\inst\extdata\QQI\pgen\genotype.pvar
Fast3VmrMLM\inst\extdata\QQI\pgen\genotype.psam
Fast3VmrMLM\inst\extdata\QQI\VCF\phenotype.csv

Phenotypes are shared with QQI/VCF; no duplicate copy is stored.

------Chinese------
QQI - pgen 示例数据

运行所用文件：
Fast3VmrMLM\inst\extdata\QQI\pgen\genotype.pgen
Fast3VmrMLM\inst\extdata\QQI\pgen\genotype.pvar
Fast3VmrMLM\inst\extdata\QQI\pgen\genotype.psam
Fast3VmrMLM\inst\extdata\QQI\VCF\phenotype.csv

表型与 QQI/VCF 共用，不重复存放。
