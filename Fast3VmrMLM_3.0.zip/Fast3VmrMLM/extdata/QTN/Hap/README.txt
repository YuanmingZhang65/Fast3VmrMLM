﻿------English------
QTN - Hap example data

Files used for this analysis:
Fast3VmrMLM\inst\extdata\QTN\SNP\genotype.bed
Fast3VmrMLM\inst\extdata\QTN\SNP\genotype.bim
Fast3VmrMLM\inst\extdata\QTN\SNP\genotype.fam
Fast3VmrMLM\inst\extdata\QTN\SNP\phenotype.csv
Fast3VmrMLM\inst\extdata\QTN\SNP\PCA.csv

Genotypes, phenotypes, and PCA are shared with QTN/SNP; no duplicate data copies are stored. The Hap example uses c_threshold=0.7.

------Chinese------
QTN - Hap 示例数据

运行所用文件：
Fast3VmrMLM\inst\extdata\QTN\SNP\genotype.bed
Fast3VmrMLM\inst\extdata\QTN\SNP\genotype.bim
Fast3VmrMLM\inst\extdata\QTN\SNP\genotype.fam
Fast3VmrMLM\inst\extdata\QTN\SNP\phenotype.csv
Fast3VmrMLM\inst\extdata\QTN\SNP\PCA.csv

与 QTN/SNP 共用基因型、表型和 PCA，不重复存放数据。Hap 示例 c_threshold=0.7。
