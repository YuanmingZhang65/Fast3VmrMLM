﻿------English------
QTN - NCII example data

Files used for this analysis:
Fast3VmrMLM\inst\extdata\QTN\NCII\genotype.bed
Fast3VmrMLM\inst\extdata\QTN\NCII\genotype.bim
Fast3VmrMLM\inst\extdata\QTN\NCII\genotype.fam
Fast3VmrMLM\inst\extdata\QTN\NCII\phenotype.csv
Fast3VmrMLM\inst\extdata\QTN\NCII\PCA.csv
Fast3VmrMLM\inst\extdata\QTN\NCII\pedigree.csv

------Chinese------
QTN - NCII 示例数据

运行所用文件：
Fast3VmrMLM\inst\extdata\QTN\NCII\genotype.bed
Fast3VmrMLM\inst\extdata\QTN\NCII\genotype.bim
Fast3VmrMLM\inst\extdata\QTN\NCII\genotype.fam
Fast3VmrMLM\inst\extdata\QTN\NCII\phenotype.csv
Fast3VmrMLM\inst\extdata\QTN\NCII\PCA.csv
Fast3VmrMLM\inst\extdata\QTN\NCII\pedigree.csv
