﻿------English------
QTN - SNP example data

Files used for this analysis:
Fast3VmrMLM\inst\extdata\QTN\SNP\genotype.bed
Fast3VmrMLM\inst\extdata\QTN\SNP\genotype.bim
Fast3VmrMLM\inst\extdata\QTN\SNP\genotype.fam
Fast3VmrMLM\inst\extdata\QTN\SNP\phenotype.csv
Fast3VmrMLM\inst\extdata\QTN\SNP\PCA.csv

------Chinese------
QTN - SNP 示例数据

运行所用文件：
Fast3VmrMLM\inst\extdata\QTN\SNP\genotype.bed
Fast3VmrMLM\inst\extdata\QTN\SNP\genotype.bim
Fast3VmrMLM\inst\extdata\QTN\SNP\genotype.fam
Fast3VmrMLM\inst\extdata\QTN\SNP\phenotype.csv
Fast3VmrMLM\inst\extdata\QTN\SNP\PCA.csv
