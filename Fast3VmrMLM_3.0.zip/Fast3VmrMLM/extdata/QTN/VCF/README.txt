﻿------English------
QTN - VCF example data

Files used for this analysis:
Fast3VmrMLM\inst\extdata\QTN\VCF\genotype.vcf
Fast3VmrMLM\inst\extdata\QTN\VCF\phenotype.csv

------Chinese------
QTN - VCF 示例数据

运行所用文件：
Fast3VmrMLM\inst\extdata\QTN\VCF\genotype.vcf
Fast3VmrMLM\inst\extdata\QTN\VCF\phenotype.csv
