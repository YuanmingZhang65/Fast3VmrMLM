﻿------English------
QTN - pgen example data

Files used for this analysis:
Fast3VmrMLM\inst\extdata\QTN\pgen\genotype.pgen
Fast3VmrMLM\inst\extdata\QTN\pgen\genotype.pvar
Fast3VmrMLM\inst\extdata\QTN\pgen\genotype.psam
Fast3VmrMLM\inst\extdata\QTN\VCF\phenotype.csv

Phenotypes are shared with QTN/VCF; no duplicate copy is stored.

------Chinese------
QTN - pgen 示例数据

运行所用文件：
Fast3VmrMLM\inst\extdata\QTN\pgen\genotype.pgen
Fast3VmrMLM\inst\extdata\QTN\pgen\genotype.pvar
Fast3VmrMLM\inst\extdata\QTN\pgen\genotype.psam
Fast3VmrMLM\inst\extdata\QTN\VCF\phenotype.csv

表型与 QTN/VCF 共用，不重复存放。
