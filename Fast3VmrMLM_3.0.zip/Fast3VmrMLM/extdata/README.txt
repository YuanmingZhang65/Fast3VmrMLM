﻿------English------
Example data location: Fast3VmrMLM\inst\extdata\

QTN: Fast3VmrMLM\inst\extdata\QTN\
QEI: Fast3VmrMLM\inst\extdata\QEI\
QQI: Fast3VmrMLM\inst\extdata\QQI\

Each module has five subfolders: SNP, NCII, Hap, VCF, and pgen. The README.txt in each subfolder lists the full package-relative paths of the data files used.
Only one copy of shared data is kept and referenced by the run scripts. If a folder contains only README.txt, use the data locations specified in that file.

Run scripts: Fast3VmrMLM\inst\extdata\run_QTN.R, Fast3VmrMLM\inst\extdata\run_QEI.R, Fast3VmrMLM\inst\extdata\run_QQI.R.

------Chinese------
示例数据统一位置：Fast3VmrMLM\inst\extdata\

QTN：Fast3VmrMLM\inst\extdata\QTN\
QEI：Fast3VmrMLM\inst\extdata\QEI\
QQI：Fast3VmrMLM\inst\extdata\QQI\

每个模块均设 SNP、NCII、Hap、VCF、pgen 五个子文件夹；各子文件夹 README.txt 列出实际使用的数据完整包内路径。
共享数据只保留一份，通过运行脚本引用；文件夹只有 README.txt 时，数据位置以其中说明为准。

运行代码：Fast3VmrMLM\inst\extdata\run_QTN.R、Fast3VmrMLM\inst\extdata\run_QEI.R、Fast3VmrMLM\inst\extdata\run_QQI.R。
