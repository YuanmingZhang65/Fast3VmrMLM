library(Fast3VmrMLM)

data_dir <- system.file("extdata", package="Fast3VmrMLM")
# Results are saved in the result folder under the current working directory.
# 结果保存到当前工作目录下的 result 文件夹。
result_dir <- file.path(getwd(), "result")

# QEI - SNP
Fast3VmrMLM_MEJA(fileGen=file.path(data_dir, "QTN/SNP/genotype"), filePhe=file.path(data_dir, "QEI/SNP/phenotype.csv"),
    filePS=file.path(data_dir, "QTN/SNP/PCA.csv"), fileOut=file.path(result_dir, "QEI/SNP/"),
    genoType="SNP", trait=1:3,
    n_en=c(2,2,2), svpal=0.01,
    svrad=2e+4, svmlod=3,
    DrawPlot=TRUE)

# QEI - NCII
Fast3VmrMLM_MEJA(fileGen=file.path(data_dir, "QTN/NCII/genotype"), filePhe=file.path(data_dir, "QEI/NCII/phenotype.csv"),
    filePS=file.path(data_dir, "QTN/NCII/PCA.csv"), fileOut=file.path(result_dir, "QEI/NCII/"),
    population="NCII", filePedigree=file.path(data_dir, "QTN/NCII/pedigree.csv"),
    trait=1:2, n_en=c(3,3),
    svpal=0.01, svrad=2e+4,
    svmlod=3, DrawPlot=TRUE)

# QEI - Hap
Fast3VmrMLM_MEJA(fileGen=file.path(data_dir, "QTN/SNP/genotype"), filePhe=file.path(data_dir, "QEI/SNP/phenotype.csv"),
    filePS=file.path(data_dir, "QTN/SNP/PCA.csv"), fileOut=file.path(result_dir, "QEI/Hap/"),
    genoType="Hap", trait=1:3,
    n_en=c(2,2,2), svpal=0.01,
    svrad=2e+4, svmlod=3,
    c_threshold=0.7, numofHaplotypes=3,
    DrawPlot=TRUE)

# QEI - VCF
Fast3VmrMLM_MEJA_SV(fileGen=file.path(data_dir, "QEI/VCF/genotype.vcf"), filePhe=file.path(data_dir, "QEI/VCF/phenotype.csv"),
    filePS=file.path(data_dir, "QTN/SNP/PCA.csv"), fileOut=file.path(result_dir, "QEI/VCF/"),
    trait=1:2, n_env=c(2,2),
    svpal=0.01, svrad=1e+4,
    svmlod=3, numofHaplotypes=6,
    DrawPlot=TRUE)

# QEI - pgen
Fast3VmrMLM_MEJA_SV_PGEN(fileGen=file.path(data_dir, "QEI/pgen/genotype"), filePhe=file.path(data_dir, "QEI/VCF/phenotype.csv"),
    filePS=file.path(data_dir, "QTN/SNP/PCA.csv"), fileOut=file.path(result_dir, "QEI/pgen/"),
    trait=1:2, n_env=c(2,2),
    svpal=0.01, svrad=1e+4,
    svmlod=3, numofHaplotypes=6,
    threads=2, DrawPlot=TRUE)
