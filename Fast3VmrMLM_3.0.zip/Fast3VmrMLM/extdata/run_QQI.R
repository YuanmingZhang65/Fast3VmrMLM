

library(Fast3VmrMLM)

data_dir <- system.file("extdata", package="Fast3VmrMLM")
# Results are saved in the result folder under the current working directory.
# 结果保存到当前工作目录下的 result 文件夹。
result_dir <- file.path(getwd(), "result")

# QQI - SNP
Fast3VmrMLM_QQI(fileGen=file.path(data_dir, "QQI/SNP/genotype"), filePhe=file.path(data_dir, "QQI/SNP/phenotype.csv"),
    filePS=file.path(data_dir, "QQI/SNP/PCA.csv"), fileOut=file.path(result_dir, "QQI/SNP/"),
    genoType="SNP", trait=1:2,
    plinkdir="G:/plink_win64_20220402/", plinkepi1=1e-5,
    thinMarker=TRUE, LDthin_threshold=0.8,
    LDthin_max.dist=200e3, svpal=1e-8,
    svpal_ad=1e-3, svrad=1e+4,
    svmlod=3, svmlod_QQI=3)

# QQI - NCII
Fast3VmrMLM_QQI(fileGen=file.path(data_dir, "QQI/NCII/genotype"), filePhe=file.path(data_dir, "QQI/NCII/phenotype.csv"),
    filePS=file.path(data_dir, "QQI/NCII/PCA.csv"), fileOut=file.path(result_dir, "QQI/NCII/"),
    population="NCII", filePedigree=file.path(data_dir, "QQI/NCII/pedigree.csv"),
    trait=1:2, plinkdir="G:/plink_win64_20220402/",
    plinkepi1=1e-5, thinMarker=TRUE,
    LDthin_threshold=0.8, LDthin_max.dist=200e3,
    svpal=1e-8, svpal_ad=1e-3,
    svrad=10, svmlod=3,
    svmlod_QQI=3)

# QQI - Hap
Fast3VmrMLM_QQI(fileGen=file.path(data_dir, "QQI/SNP/genotype"), filePhe=file.path(data_dir, "QQI/SNP/phenotype.csv"),
    filePS=file.path(data_dir, "QQI/SNP/PCA.csv"), fileOut=file.path(result_dir, "QQI/Hap/"),
    genoType="Hap", trait=1:2,
    plinkdir="G:/plink_win64_20220402/", plinkepi1=1e-5,
    thinMarker=TRUE, LDthin_threshold=0.8,
    LDthin_max.dist=200e3, svpal=1e-5,
    svpal_ad=1e-3, svrad=10,
    svmlod=3, svmlod_QQI=3,
    c_threshold=0.7, numofHaplotypes=3)

# QQI - VCF
Fast3VmrMLM_SV_QQI(fileGen=file.path(data_dir, "QQI/VCF/genotype.vcf"), filePhe=file.path(data_dir, "QQI/VCF/phenotype.csv"),
    filePS=NULL, fileOut=file.path(result_dir, "QQI/VCF/"),
    trait=1:2, plinkdir="G:/plink_win64_20220402/",
    plinkepi1=1e-5, svpal=1e-5,
    svrad=1e+4, svmlod=3,
    numofHaplotypes=6, DrawPlot=TRUE)

# QQI - pgen
Fast3VmrMLM_SV_QQI_PGEN(fileGen=file.path(data_dir, "QQI/pgen/genotype"), filePhe=file.path(data_dir, "QQI/VCF/phenotype.csv"),
    filePS=NULL, fileOut=file.path(result_dir, "QQI/pgen/"),
    trait=1:2, plinkdir="G:/plink_win64_20220402/",
    plinkepi1=1e-5, svpal=1e-5,
    svrad=1e+4, svmlod=3,
    numofHaplotypes=6, threads=2, DrawPlot=TRUE)
