library(Fast3VmrMLM)

data_dir <- system.file("extdata", package="Fast3VmrMLM")
# Results are saved in the result folder under the current working directory.
# 结果保存到当前工作目录下的 result 文件夹。
result_dir <- file.path(getwd(), "result")

# QTN - SNP
Fast3VmrMLM(fileGen=file.path(data_dir, "QTN/SNP/genotype"), filePhe=file.path(data_dir, "QTN/SNP/phenotype.csv"),
    filePS=file.path(data_dir, "QTN/SNP/PCA.csv"), fileOut=file.path(result_dir, "QTN/SNP/"),
    genoType="SNP", trait=1:3,
    svpal=0.01, svrad=2e+4,
    svmlod=3, DrawPlot=TRUE)

# QTN - NCII
Fast3VmrMLM(fileGen=file.path(data_dir, "QTN/NCII/genotype"), filePhe=file.path(data_dir, "QTN/NCII/phenotype.csv"),
    filePS=file.path(data_dir, "QTN/NCII/PCA.csv"), fileOut=file.path(result_dir, "QTN/NCII/"),
    population="NCII", filePedigree=file.path(data_dir, "QTN/NCII/pedigree.csv"),
    trait=1:2, svpal=0.01,
    svrad=2e+4, svmlod=3,
    DrawPlot=TRUE)

# QTN - Hap
Fast3VmrMLM(fileGen=file.path(data_dir, "QTN/SNP/genotype"), filePhe=file.path(data_dir, "QTN/SNP/phenotype.csv"),
    filePS=file.path(data_dir, "QTN/SNP/PCA.csv"), fileOut=file.path(result_dir, "QTN/Hap/"),
    genoType="Hap", trait=1:3,
    svpal=0.01, svrad=2e+4,
    svmlod=3, c_threshold=0.7,
    numofHaplotypes=3, DrawPlot=TRUE)

# QTN - VCF
Fast3VmrMLM_SV(fileGen=file.path(data_dir, "QTN/VCF/genotype.vcf"), filePhe=file.path(data_dir, "QTN/VCF/phenotype.csv"),
    filePS=NULL, fileOut=file.path(result_dir, "QTN/VCF/"),
    trait=1:3, svpal=0.01,
    svrad=1e+4, svmlod=3,
    numofHaplotypes=6, DrawPlot=TRUE)

# QTN - pgen
Fast3VmrMLM_SV_PGEN(fileGen=file.path(data_dir, "QTN/pgen/genotype"), filePhe=file.path(data_dir, "QTN/VCF/phenotype.csv"),
    filePS=NULL, fileOut=file.path(result_dir, "QTN/pgen/"),
    trait=1:3, svpal=0.01,
    svrad=1e+4, svmlod=3,
    numofHaplotypes=6, threads=2,
    DrawPlot=TRUE)
