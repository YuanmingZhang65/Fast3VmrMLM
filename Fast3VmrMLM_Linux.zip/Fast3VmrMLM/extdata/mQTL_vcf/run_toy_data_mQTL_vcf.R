
    
    library(Fast3VmrMLM)
    
    
    fileGen="/home/WJT/genenotype_mQTL_vcf.vcf"
    filePhe="/home/WJT/trait_mQTL_vcf.csv"
    fileOut="/home/WJT/"

    
    Fast3VmrMLM(fileGen=fileGen, filePhe=filePhe, fileOut=fileOut,
               MGinputClass="vcf",genoType = "molecular",
               trait = 1:3,
               svpal=0.01, svrad=0,
               midout=TRUE, svmlod=3)
    
    
    
    
    
    
    