    
    

    library(Fast3VmrMLM)
    

    Fast3VmrMLM(fileGen="/home/WJT/genotype",filePhe="/home/WJT/trait",filePS="/home/WJT/PCA.csv",PopStrType="PC",fileOut="/home/WJT/",
                genoType="SNP",trait=1:3,svrad=10,svpal=0.05/1000,svmlod=3,
                scainngParallel=TRUE,nThreads=20,DrawPlot=TRUE,Plotformat="*.tiff")
    
    
    
    

    
    