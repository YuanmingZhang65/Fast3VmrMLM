    
    

    library(Fast3VmrMLM)
    
    Fast3VmrMLM(fileGen="/home/WJT/genotype",filePhe="/home/WJT/trait.csv",filePS="/home/WJT/PCA.csv",PopStrType="PC",fileOut="/home/WJT/",
                genoType="Hap",trait=1:3,svrad=10,svpal=0.01,svmlod=3,
                scainngParallel=TRUE,nThreads=20,
                c_threshold=0.7,numofHaplotypes=3)
    