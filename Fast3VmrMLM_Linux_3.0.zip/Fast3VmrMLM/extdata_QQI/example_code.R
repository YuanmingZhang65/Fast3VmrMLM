




    ##### Fast3VmrMLM
    #####
    library(Fast3VmrMLM)

    Fast3VmrMLM_QQI(fileGen="/home/WJT/FAST3V2/package_Fast3VmrMLM_extdata/QQI_extdata/SNP/data/SNPsubset2_renamed_300",
                    filePhe="/home/WJT/FAST3V2/package_Fast3VmrMLM_extdata/QQI_extdata/SNP/data/quantitative_Simulation_II_2_renamed_300.csv",
                    filePS="/home/WJT/FAST3V2/package_Fast3VmrMLM_extdata/QQI_extdata/SNP/data/2pca_renamed_300.csv",
                    fileOut="/home/WJT/FAST3V2/package_Fast3VmrMLM_extdata/QQI_extdata/SNP/result/",
                    genoType = "SNP",
                    trait = 1:2,
                    thinMarker = TRUE,  LDthin_threshold = 0.8, LDthin_max.dist = 200e3, # LD thin, LDthin_max.dist (bp)
                    plinkdir="/home/WJT/plink/", plinkepi1=1e-5,                         # plink scan
                    svpal = 1e-8, svpal_ad=1e-3, svrad = 1e+4,                             # MLM-based scanb
                    svmlod = 3, svmlod_QQI = 3)                                          # ML & Likelihood ratio test




    ##### Fast3VmrMLM-Hap
    #####
    library(Fast3VmrMLM)

    Fast3VmrMLM_QQI(fileGen="/home/WJT/FAST3V2/package_Fast3VmrMLM_extdata/QQI_extdata/SNP/data/SNPsubset2_renamed_300",
                    filePhe="/home/WJT/FAST3V2/package_Fast3VmrMLM_extdata/QQI_extdata/SNP/data/quantitative_Simulation_II_2_renamed_300.csv",
                    filePS="/home/WJT/FAST3V2/package_Fast3VmrMLM_extdata/QQI_extdata/SNP/data/2pca_renamed_300.csv",
                    fileOut="/home/WJT/FAST3V2/package_Fast3VmrMLM_extdata/QQI_extdata/Hap/result/",
                    genoType = "Hap", c_threshold = 0.9, numofHaplotypes = 3,
                    trait = 1:2,
                    thinMarker = TRUE,  LDthin_threshold = 0.8, LDthin_max.dist = 200e3,
                    plinkdir="/home/WJT/plink/", plinkepi1=1e-5,
                    svpal = 1e-5, svpal_ad=1e-3, svrad = 10,
                    svmlod = 3, svmlod_QQI = 3)





    ##### Fast3VmrMLM-NCII
    #####
    library(Fast3VmrMLM)

    Fast3VmrMLM_QQI(fileGen="/home/WJT/FAST3V2/package_Fast3VmrMLM_extdata/QQI_extdata/SNP/data/sample_1000",
                    filePhe="/home/WJT/FAST3V2/package_Fast3VmrMLM_extdata/QQI_extdata/SNP/data/quantitative_Simulation_I_2.csv",
                    filePS="/home/WJT/FAST3V2/package_Fast3VmrMLM_extdata/QQI_extdata/SNP/data/pca_Simulation_I_2.csv",
                    population = "NCII", filePedigree="/home/WJT/FAST3V2/package_Fast3VmrMLM_extdata/QQI_extdata/NCII/data/pedigree.csv",
                    fileOut="/home/WJT/FAST3V2/package_Fast3VmrMLM_extdata/QQI_extdata/NCII/result/",
                    genoType = "SNP",
                    trait = 1:3,
                    thinMarker = TRUE,  LDthin_threshold = 0.8, LDthin_max.dist = 200e3,
                    plinkdir="/home/WJT/plink/", plinkepi1=1e-5,
                    svpal = 1e-8, svpal_ad=1e-3, svrad = 10,
                    svmlod = 3, svmlod_QQI = 3)



    ##### Fast3VmrMLM-mQTL
    #####
    library(Fast3VmrMLM)

    Fast3VmrMLM_SV_QQI(fileGen="/home/WJT/FAST3V2/package_Fast3VmrMLM_extdata/QQI_extdata/SV/data/sv.lumpy2.sub300.keep_QTN_QQI.vcf",
                        filePhe="/home/WJT/FAST3V2/package_Fast3VmrMLM_extdata/QQI_extdata/SV/data/quantitative_Simulation_SV_QQI_1.csv",
                        filePS=NULL,
                        fileOut="/home/WJT/FAST3V2/package_Fast3VmrMLM_extdata/QQI_extdata/SV/result/",
                        trait = 1:2,
                        plinkdir="/home/WJT/plink/", plinkepi1=1e-5,
                        svpal = 1e-8, svrad = 1e+4,
                        svmlod = 3)











