
    
    library(Fast3VmrMLM)
    
    
    fileGen="/home/WJT/FAST3V2_sim/data_100inds_10000snps"
    filePhe="/home/WJT/quantitative_Simulation_bed.csv"
    filegeneRegion = "/home/WJT/trait.csv"

    
    Fast3VmrMLM(fileGen=fileGen, filePhe=filePhe, fileOut="/home/WJT/",
               MGinputClass="bed",genoType = "molecular",filegeneRegion=filegeneRegion,
               trait = 1:3,
               svpal=0.01, svrad=0,numofHaplotypes = 6,
               midout=TRUE, svmlod=3)
    
    
    
    
    
    
    