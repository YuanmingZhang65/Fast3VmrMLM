    

    ### ### ### ### ### ### Fast3VmrMLM
    ### ### ### ### ### ### 

    library(Fast3VmrMLM)
    
    Fast3VmrMLM(fileGen="E:/example/extdata/genotype",
                filePhe="E:/example/extdata/trait.csv",
                filePS="E:/example/extdata/PCA.csv", PopStrType="PC",
                fileOut="E:/example/result/extdata/SNP/",
                trait=1:3, svrad=2e+4, svpal=1e-5, svmlod=3,
                DrawPlot=T, Plotformat="*.tiff")



    ### ### ### ### ### ### Fast3VmrMLM-Hap
    ### ### ### ### ### ### 
    
    library(Fast3VmrMLM)
    
    Fast3VmrMLM(fileGen="E:/example/extdata/genotype",
                filePhe="E:/example/extdata/trait.csv",
                filePS="E:/example/extdata/PCA.csv",PopStrType="PC",
                fileOut="E:/example/result/extdata/Hap/",
                genoType="Hap",
                trait=1:3,svrad=2e+4,svpal=0.01,svmlod=3, c_threshold=0.7, numofHaplotypes=3,
                DrawPlot=T, Plotformat="*.tiff")
    
    
    ### ### ### ### ### ### Fast3VmrMLM-NCII
    ### ### ### ### ### ### 
    Fast3VmrMLM(fileGen="E:/example/extdata/NCII/Genotype",
                filePhe="E:/example/extdata/NCII/phenotype.csv",
                filePS="E:/example/extdata/NCII/PopStr.csv",PopStrType="PC",
                filePedigree="E:/example/extdata/NCII/pedigree.csv",
                population="NCII",
                fileOut="E:/example/result/extdata/NCII/",
                trait=1:2, svrad=2e+4, svpal=1e-5, svmlod=3,
                DrawPlot=T, Plotformat="*.tiff")
    
    
    ### ### ### ### ### ### Fast3VmrMLM-mQTL     vcf
    ### ### ### ### ### ### 
    
    library(Fast3VmrMLM)
    
    Fast3VmrMLM_SV(fileGen="E:/example/extdata/mQTL_vcf/genenotype_mQTL_vcf.vcf",
                   filePhe="E:/example/extdata/mQTL_vcf/trait_mQTL_vcf.csv",
                   filePS=NULL,
                   fileOut="E:/example/result/extdata/mQTL/",
                   trait=1:3, svpal=0.01, svrad=1e+4, svmlod=3)
    
    
    
    
    
    # ### ### ### ### ### ### Fast3VmrMLM-mQTL     vcf
    # ### ### ### ### ### ### 
    # 
    # library(Fast3VmrMLM)
    # 
    # Fast3VmrMLM_dosage(fileGen="E:/example/extdata/mQTL_vcf/genenotype_mQTL_vcf.vcf",
    #                    filePhe="E:/example/extdata/mQTL_vcf/trait_mQTL_vcf.csv",
    #                    filePS=NULL,
    #                    fileOut="E:/example/result/extdata/dosage/",
    #                    trait=1:3,p_select=0.01,svrad=-1,svmlod=3)
    
    # ### ### ### ### ### ### Fast3VmrMLM-mQTL     bed, bim, fam
    # ### ### ### ### ### ### 
    # 
    # library(Fast3VmrMLM)
    # 
    # Fast3VmrMLM(fileGen="E:/example/extdata/mQTL_bed/data_100inds_10000snps",
    #             filePhe="E:/example/extdata/mQTL_bed/trait.csv",
    #             filePS="E:/example/extdata/mQTL_bed/PCA.csv", PopStrType="PC",
    #             filegeneRegion="E:/example/extdata/mQTL_bed/maize_gene_100.csv",
    #             fileOut="E:/example/result/extdata/mQTL/",
    #             genoType="Gene",
    #             trait=1,svrad=2e+4,svpal=1e-5, svmlod=3, numofHaplotypes=3)
    
    
    
    
