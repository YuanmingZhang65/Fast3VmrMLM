    
    
    ### ### ### ### ### ### Fast3VmrMLM_MEJA
    ### ### ### ### ### ### 
    library(Fast3VmrMLM)
    
    Fast3VmrMLM_MEJA(fileGen="E:/example/extdata_MEJA/genotype",
                     filePhe="E:/example/extdata_MEJA/quantitative_trait_MEJA.csv",
                     filePS="E:/example/extdata_MEJA/PCA.csv", PopStrType="PC",
                     fileOut="E:/example/result/extdata_MEJA/SNP_MEJA/",
                     trait=1:3, n_en = c(2, 2, 2),
                     svrad=2e+4, svpal=1e-5, svmlod=3,
                     DrawPlot=T, Plotformat="*.tiff")
    
    
    
    
    ### ### ### ### ### ### Fast3VmrMLM_MEJA-Hap
    ### ### ### ### ### ### 
    library(Fast3VmrMLM)
    
    Fast3VmrMLM_MEJA(fileGen="E:/example/extdata_MEJA/genotype",
                     filePhe="E:/example/extdata_MEJA/quantitative_trait_MEJA.csv",
                     filePS="E:/example/extdata_MEJA/PCA.csv", PopStrType="PC",
                     fileOut="E:/example/result/extdata_MEJA/Hap_MEJA/",
                     genoType="Hap", trait=1:3, n_en = c(2, 2, 2),
                     svrad=2e+4, svpal=1e-5,svmlod=3, c_threshold=0.7, numofHaplotypes=3,
                     DrawPlot=T, Plotformat="*.tiff")

    
    ### ### ### ### ### ### Fast3VmrMLM_MEJA-NCII
    ### ### ### ### ### ### 
    
    library(Fast3VmrMLM)
    Fast3VmrMLM_MEJA(fileGen="E:/example/extdata_MEJA/NCII/geno",
                     filePhe="E:/example/extdata_MEJA/NCII/phe.csv",
                     filePS="E:/example/extdata_MEJA/NCII/PopStr.csv",
                     filePedigree="E:/example/extdata_MEJA/NCII/pedigree.csv",PopStrType="PC",
                     population="NCII",
                     fileOut="E:/example/result/extdata_MEJA/NCII_MEJA/",
                     trait=1:2, n_en=c(3,3),svrad=2e+4,svpal=1e-5,svmlod=3,
                     DrawPlot=TRUE,Plotformat="*.tiff")
    
    
    
    ### ### ### ### ### ### Fast3VmrMLM_MEJA for structural variations or discrete genotypes
    ### ### ### ### ### ### 
    library(Fast3VmrMLM)
    
    Fast3VmrMLM_MEJA_SV(fileGen="E:/example/extdata_MEJA/mQTL/gene_SV.vcf",
                         filePhe="E:/example/extdata_MEJA/mQTL/quantitative_SV.csv",
                         filePS="E:/example/extdata_MEJA/PCA.csv", PopStrType="PC",
                         fileOut="E:/example/result/extdata_MEJA/mQTL_MEJA/",
                         trait = 1:2, n_env=c(2, 2),
                         numofHaplotypes = 3,
                         svpal=1e-5, svrad=2e+4, svmlod=3)
    
    
    
    
    # ### ### ### ### ### ### Fast3VmrMLM_MEJA for continuous genotypes
    # ### ### ### ### ### ### 
    # library(Fast3VmrMLM)
    # 
    # Fast3VmrMLM_dosage_MEJA(fileGen="E:/example/extdata_MEJA/mQTL/gene_dosage.vcf",
    #                          filePhe="E:/example/extdata_MEJA/mQTL/quantitative_dosage.csv",
    #                          filePS="E:/example/extdata_MEJA/mQTL/PCA_dosage.csv", PopStrType="PC",
    #                          fileOut="E:/example/result/extdata_MEJA/mQTL2_MEJA/",
    #                          trait = 1:2, n_env=c(2, 2),
    #                          svpal=0.01, svrad=2e+4, svmlod=3)
    
    
    
    
    
    
    
